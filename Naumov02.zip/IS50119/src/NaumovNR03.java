
public class NaumovNR03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 18;
		System.out.println("������");
		System.out.println("18");
		System.out.println("���� " + age);

	}

}
