
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 113
 */
public class Game extends JFrame {
    private static Game game_window;
    //Наумов Никиат Романович
    public static void main(String[] args) {
        game_window = new Game();
        game_window.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        game_window.setLocation(200, 50);
        game_window.setSize(900, 600);
        game_window.setResizable(false);
        GameField game_field = new GameField();
        game_window.add(game_field);
        game_window.setVisible(true);
    }
    private static void onRepaint(Graphics g) {
        g.fillOval(10, 10, 200, 100);
    }
    private static class GameField extends JPanel{
     @Override
     protected void paintComponent (Graphics g) {
         super.paintComponents(g);
         onRepaint(g);
     }
    }
}
